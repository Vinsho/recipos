from typing import Any, Dict

from stringcase import snakecase

from sqlalchemy.ext.declarative import declared_attr


class ModelBase:
    """
    ModelBase is assigned when creating SqlAlchemy -> db.Model derives from this class.
    """

    @declared_attr
    def __tablename__(self) -> str:
        return snakecase(self.__name__)  # pylint: disable=no-member

    def update(self, data: Dict[str, Any]):
        for column, value in data.items():
            if hasattr(self, column):
                setattr(self, column, value)
