import os

from dotenv import load_dotenv
from flask import Flask
from flask_restful import Api
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS
from src.model_base import ModelBase

# pylint: skip-file

load_dotenv()

app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = os.getenv("DATABASE_URI")
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.app_context().push()

CORS(app)
api = Api(app)


db = SQLAlchemy(app, model_class=ModelBase)
db.create_all()

# initialize api endpoints
from recipos.api.user import *
from recipos.api.recipe import *
