from src.base import app
from src.base import db

db.create_all()
app.run(host="0.0.0.0")
