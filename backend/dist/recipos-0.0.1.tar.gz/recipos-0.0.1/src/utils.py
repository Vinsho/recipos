from pathlib import Path

ROOT_PATH = Path(__file__).parent.parent.parent.parent
