# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['src', 'src.api', 'src.models']

package_data = \
{'': ['*']}

install_requires = \
['Flask-Cors>=3.0.10,<4.0.0',
 'Flask-HTTPAuth>=4.7.0,<5.0.0',
 'Flask-RESTful>=0.3.9,<0.4.0',
 'Flask>=2.2.2,<3.0.0',
 'PyJWT>=2.6.0,<3.0.0',
 'flask-sqlalchemy>=3.0.2,<4.0.0',
 'psycopg2>=2.9.5,<3.0.0',
 'python-dotenv>=0.21.0,<0.22.0',
 'stringcase>=1.2.0,<2.0.0']

setup_kwargs = {
    'name': 'recipos',
    'version': '0.0.1',
    'description': 'Recipos backend',
    'long_description': 'None',
    'author': 'Vinsho',
    'author_email': 'jakub.vins2@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
